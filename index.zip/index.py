def handler(event, handler):
    print(event)